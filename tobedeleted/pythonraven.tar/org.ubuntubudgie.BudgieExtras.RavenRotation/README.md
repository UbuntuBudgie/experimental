# RotationLock

RotationLock is a simple applet that lets you toggle the "Rotation Lock" feature for Budgie. Install from Budgie Welcome on Ubuntu Budgie.

![screenshot](https://github.com/UbuntuBudgie/budgie-extras/blob/master/budgie-rotation-lock/rotationlock.png)

