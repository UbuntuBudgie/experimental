import gi.repository

gi.require_version('BudgieRaven', '1.0')
from gi.repository import BudgieRaven, GObject, Gtk, Gio
import os

class BudgieRavenPluginExample(GObject.GObject, BudgieRaven.RavenPlugin):
	""" This is simply an entry point into your Budgie RavenWidget implementation.
		Note you must always override Object, and implement Plugin.
	"""

	# Good manners, make sure we have unique name in GObject type system
	__gtype_name__ = "BudgieRavenPluginExampleName"

	def __init__(self):
		""" Initialisation is important.
		"""
		GObject.Object.__init__(self)

	def do_new_widget_instance(self, uuid, settings):
		return BudgieRavenWidgetExample(uuid, settings)

	def do_supports_settings(self):
		return True


class BudgieRavenWidgetExample(BudgieRaven.RavenWidget):
	manager = None

	def __init__(self, uuid, settings):
		BudgieRaven.RavenWidget.__init__(self)
		#initialize(uuid, settings)